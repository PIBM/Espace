import javax.swing.JOptionPane;
import java.io.DataOutputStream;
import java.io.IOException;
import java.awt.Graphics;
import java.awt.Color;

public class Planete extends Object {
    private int mPositionX, mPositionY;
    private int mProduction, mNbVaisseau, mID;
    private double mForce;
    private boolean mEstCommandee;
    private Color mCouleur;
    private String mNom;
    private Proprietaire mProprietaire;
    
    Planete(int pPositionX, int pPositionY, String pNom) {
        mNom = pNom;
        mPositionX = pPositionX;
        mPositionY = pPositionY;
        
        // mCouleur = new Color(150+(int)(Math.random() * 100), 150+(int)(Math.random() * 100), 150+(int)(Math.random() * 100));
        mCouleur = new Color(100+(int)(Math.random() * 100), 100+(int)(Math.random() * 100), 100+(int)(Math.random() * 100));
        mNbVaisseau = 0;
        mForce = 0.75 + (Math.random() * 0.5);
        mProduction = 6 + (int)Math.pow(Math.random() * 4, 2);

        mID = 0;
        
        mEstCommandee = false;
    }
    
    public void enregistre(DataOutputStream pFichier) throws IOException {
        pFichier.writeUTF(mNom);
        pFichier.writeInt(mID);
        pFichier.writeInt(mProprietaire.reqID());        
        pFichier.writeInt(mPositionX);
        pFichier.writeInt(mPositionY);
        pFichier.writeInt(mProduction);
        pFichier.writeInt(mNbVaisseau);
        pFichier.writeInt(mCouleur.getRGB());
        pFichier.writeDouble(mForce);
        pFichier.writeBoolean(mEstCommandee);
    }

    public void asgnID(int pID) {
        mID = pID;
    }
    
    public int reqID() {
        return mID;
    }
    
    public void paint(Graphics pGraphics) {
        pGraphics.setColor(mCouleur);
        pGraphics.fillOval(10 * mPositionX, 10*mPositionY, 10, 10);
    }
    
    public void asgnProprietaire(Proprietaire pProprietaire) {
        mProprietaire = pProprietaire;
        asgnCouleur();
    }
    
    public void asgnCouleur() {
        if (mProprietaire.reqEstJoueur()) {
            mCouleur = mProprietaire.reqCouleur();
        }
    }        
    
    public Proprietaire reqProprietaire() {
        return mProprietaire;
    }

    public void asgnProduction(int pProduction) {
        mProduction = pProduction;
    }
    
    public int reqProduction() {
        return mProduction;
    }
    
    public int reqNbVaisseau() {
        return mNbVaisseau;
    }
    
    public void soustraitNbVaisseau(int pNbVaisseau) {
        mNbVaisseau -= pNbVaisseau;
    }
    
    public String reqNom() {
        return mNom;
    }
    
    public void asgnEstCommandee(boolean pValeur) {
        mEstCommandee = pValeur;
    }
    
    public boolean reqEstCommandee() {
        return mEstCommandee;
    }
    
    public int reqTemps(Planete pDestination) {
        return (int)(Math.sqrt((pDestination.mPositionX - mPositionX)*(pDestination.mPositionX - mPositionX)+
                              (pDestination.mPositionY - mPositionY)*(pDestination.mPositionY - mPositionY))
                              *0.5/mProprietaire.reqBonusDeplacement());
    }
    
    public String toString() {
        String lString = "Plan�te '" + mNom + "', ";
        
        if (mProprietaire == null) 
            lString += "libre.";
        else
            lString += "appartenant � " + mProprietaire.reqNom() + " et produisant " + mProduction + " unit�s par tour.";
        
        return lString;
    }
        
    public void avanceTour() {
        mNbVaisseau += (int)(mProduction * mProprietaire.reqBonusProduction());
    }
    
    public void recoitFlotte(Flotte pFlotte) {
        if (mProprietaire == pFlotte.reqProprietaire()) {
            mNbVaisseau += pFlotte.reqNbVaisseau();
            JOptionPane.showMessageDialog(null, "Renfort arriv�s � la planete " + mNom + ", propri�t� de " + mProprietaire.reqNom() + " !");
        } else {
            double lAttaque = pFlotte.reqNbVaisseau() * pFlotte.reqProprietaire().reqBonusAttaque();
            double lDefense = mNbVaisseau * mForce * mProprietaire.reqBonusDefense();
            
            String lNom;
            lNom = mProprietaire.reqNom();
            
            if (lAttaque > lDefense) {
                JOptionPane.showMessageDialog(null, pFlotte.reqProprietaire().reqNom() + " a pris la plan�te " + mNom + ", ancienne propri�t� de " + lNom + " !");
                mProprietaire = pFlotte.reqProprietaire();
                mCouleur = mProprietaire.reqCouleur();
                
                mNbVaisseau = (int)((lAttaque - lDefense*0.66)/mProprietaire.reqBonusDeplacement());
                mEstCommandee = false;
            } else {
                mNbVaisseau = (int)((lDefense - (0.66 * lAttaque))/(mForce*mProprietaire.reqBonusDefense()));
                JOptionPane.showMessageDialog(null, pFlotte.reqProprietaire().reqNom() + " a attaqu� la plan�te " + mNom + ", propri�t� de " + lNom + " !");
            }
        }
    }
    
}