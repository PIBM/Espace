import java.io.DataOutputStream;
import java.io.IOException;

public class Commande extends Object {
    private Planete aPlaneteSource, aPlaneteDestination;
    private int aNbVaisseau;
    
    Commande(Planete pSource, Planete pDestination, int pNbVaisseau) {
        aPlaneteSource = pSource;
        aPlaneteDestination = pDestination;
        aNbVaisseau = pNbVaisseau;
    }
    
    public void enregistre(DataOutputStream pFichier) throws IOException {    
        pFichier.writeInt(aNbVaisseau);
        pFichier.writeInt(aPlaneteSource.reqID());
        pFichier.writeInt(aPlaneteDestination.reqID());
    }
    
    public Planete reqPlaneteSource() {
        return aPlaneteSource;
    }
    
    public Planete reqPlaneteDestination() {
        return aPlaneteDestination;
    }
    
    public int reqNbVaisseau() {
        return aNbVaisseau;
    }
}