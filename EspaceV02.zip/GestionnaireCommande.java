import java.util.AbstractList;
import java.util.LinkedList;
import java.util.ListIterator;
import java.io.DataOutputStream;
import java.io.IOException;

public class GestionnaireCommande extends Object {
    private AbstractList aListeCommande;
    private Espace aEspace;
    
    GestionnaireCommande() {
        aListeCommande = new LinkedList();
    }
    
    public void enregistre(DataOutputStream pFichier) throws IOException {    
        pFichier.writeInt(aListeCommande.size());
        ListIterator lIterateur = aListeCommande.listIterator();
        while (lIterateur.hasNext()) {
            ((Commande)lIterateur.next()).enregistre(pFichier);
        }
    }
    
    public void additionneCommande(Planete pPlaneteSource, Planete pPlaneteDestination, int pNbVaisseau) {
        enlevePlanete(pPlaneteSource);
        
        aListeCommande.add(new Commande(pPlaneteSource, pPlaneteDestination, pNbVaisseau));
        pPlaneteSource.asgnEstCommandee(true);
    }
    
    public void enlevePlanete(Planete pPlanete) {
        ListIterator lIterateur = aListeCommande.listIterator();
        
        while(lIterateur.hasNext()) {
            Commande lCommande = (Commande)lIterateur.next();
            
            if (lCommande.reqPlaneteSource() == pPlanete) {
                lIterateur.remove();
                break;
            }
        }
        
        pPlanete.asgnEstCommandee(false);
    }
    
    public void envoieFlottes() {
        ListIterator lIterateur = aListeCommande.listIterator();
        
        while(lIterateur.hasNext()) {
            Commande lCommande = (Commande)lIterateur.next();
            if (lCommande.reqPlaneteSource().reqEstCommandee()) {
                aEspace.envoieFlotte(lCommande.reqPlaneteSource(), lCommande.reqPlaneteDestination(), lCommande.reqNbVaisseau());
            } else {
                lIterateur.remove();
            }
        }
    }
    
    public void asgnEspace(Espace pEspace) {
        aEspace = pEspace;
    }
    
    public void libereRessources() {
        aEspace = null;
        aListeCommande = null;
    }
}