import java.io.DataOutputStream;
import java.io.IOException;

public class Flotte extends Object {
    private int mNbVaisseaux, mTempsRestant;
    private Planete mDestination;
    Proprietaire mProprietaire; 
    
    Flotte(Proprietaire pProprietaire, int pNbVaisseaux, int pTemps, Planete pDestination) {
        mProprietaire = pProprietaire;
        mNbVaisseaux = pNbVaisseaux;
        mTempsRestant = pTemps;
        
        mDestination = pDestination;
    }

    public void enregistre(DataOutputStream pFichier) throws IOException {
        pFichier.writeInt(mProprietaire.reqID());
        pFichier.writeInt(mDestination.reqID());
        pFichier.writeInt(mNbVaisseaux);
        pFichier.writeInt(mTempsRestant);
    }
    
    public boolean avanceTour() {
        if (--mTempsRestant <= 0) return true;
        return false;
    }
    
    public Planete reqDestination() {
        return mDestination;
    }
    
    public Proprietaire reqProprietaire() {
        return mProprietaire;
    }
    
    public int reqNbVaisseau() {
        return mNbVaisseaux;
    }
        
}
