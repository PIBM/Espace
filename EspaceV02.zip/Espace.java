import java.util.AbstractList;
import java.util.LinkedList;
import java.util.Vector;
import java.util.Iterator;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.zip.*;
import javax.swing.Timer;
import javax.swing.JOptionPane;


public class Espace extends JPanel implements ActionListener, MouseListener, MouseMotionListener {
    final static private Color aCouleurs[] = {Color.red, Color.blue, Color.green, Color.yellow, Color.magenta, Color.cyan, Color.orange, Color.pink};
    private Timer aTimer;
    private Planete aEspace[][], aPlaneteSource, aPlaneteDestination;
    private AbstractList aListePlanete;
    private AbstractList aListeFlotte;
    private AbstractList aListeProprietaire;
    private AbstractList aListeNomPlanete;
    private Vector aListeEtoiles;
    private GestionnaireProprietaire aGestionnaireProprietaire;
    private boolean aEnregistreCommande;
    private Donnees aDonnees;
    private Statistiques aStats;
    private GestionnaireCommande aGestionnaireCommande;
    
    public Espace() {
        setPreferredSize(new java.awt.Dimension(640, 400));
        setMinimumSize(new java.awt.Dimension(640, 400));
        
        setSize(640, 400);
        
        int lNbJoueurs = Integer.parseInt(JOptionPane.showInputDialog("Combien de joueurs ? [2,8]"));
        if (lNbJoueurs < 2) lNbJoueurs = 2;
        if (lNbJoueurs > 8) lNbJoueurs = 8;
        
        int lNbPlanetes = Integer.parseInt(JOptionPane.showInputDialog("Combien de planetes ? ["+ 4*lNbJoueurs + ", 200]"));
        if (lNbPlanetes < 4 * lNbJoueurs) lNbPlanetes = lNbJoueurs * 4;
        if (lNbPlanetes > 200) lNbPlanetes = 200;
        
        aListeFlotte = new Vector();
        aListeProprietaire = new Vector();
        aGestionnaireProprietaire = new GestionnaireProprietaire(aListeProprietaire);
        aGestionnaireCommande = new GestionnaireCommande();
        
        lisNomPlanetes();
        creePlanetes(lNbPlanetes, 64, 40);
        
        for (int i = 0; i<lNbJoueurs; ++i) {
            Proprietaire lProprietaire = new Proprietaire(JOptionPane.showInputDialog("Nom du joueur " + i + " :"), aCouleurs[i]);
            aListeProprietaire.add(lProprietaire);
            
            Planete lPlanete;
            do {
                lPlanete = (Planete)aListePlanete.get((int)(Math.random() * aListePlanete.size()));
            } while (lPlanete.reqProprietaire() != null);
            
            lPlanete.asgnProprietaire(lProprietaire);
            lPlanete.asgnProduction(10);
        }
        
        attribuePlanetesLibres();
        
        additionneEcouteurs();
        
        creeEtoiles(300);
        asgnRafraichissementEtoiles(50);
    }
    
    public Espace(ConfigurationEspace pConfig, Vector pVecteurProprietaire) {
        setPreferredSize(new java.awt.Dimension(640, 400));
        setMinimumSize(new java.awt.Dimension(640, 400));
        
        setSize(640, 400);
        
        aListeFlotte = new Vector();
        aListeProprietaire = new Vector();
        aGestionnaireProprietaire = new GestionnaireProprietaire(aListeProprietaire);
        aGestionnaireCommande = new GestionnaireCommande();
        
        creeEtoiles(pConfig.reqNbEtoiles());
        
        randomize(pConfig, pVecteurProprietaire);
        
        additionneEcouteurs();
        
        System.out.println("Termin� la construction d'un Espace !");
    }
    
    public void randomize(ConfigurationEspace pConfig, Vector pVecteurProprietaire) {
        lisNomPlanetes();
        
        if (aEspace != null) {
            for (int i = 0; i<aEspace.length; ++i) {
                for (int j = 0; j<aEspace[i].length; ++j) {
                    aEspace[i][j] = null;
                }
            }
        }
        
        if (aListePlanete != null) {
            aListePlanete.clear();
        }
        
        creePlanetes(pConfig.reqNbPlanetes(), 64, 40);
        
        aListeProprietaire.clear();
        for (int i = 0; i<pVecteurProprietaire.size(); ++i) {
            Proprietaire lProprietaire = (Proprietaire)pVecteurProprietaire.get(i);
            aListeProprietaire.add(lProprietaire);
            
            Planete lPlanete;
            do {
                lPlanete = (Planete)aListePlanete.get((int)(Math.random() * aListePlanete.size()));
            } while (lPlanete.reqProprietaire() != null);
            
            lPlanete.asgnProprietaire(lProprietaire);
            lPlanete.asgnProduction(10);
        }

        aListeProprietaire.add(attribuePlanetesLibres());
        
        if (pConfig.reqNbEtoiles() != 0) {
            asgnNbEtoiles(pConfig.reqNbEtoiles());
            asgnRafraichissementEtoiles(pConfig.reqVitesse());
        } else {
            asgnRafraichissementEtoiles(0);
        }
        
        System.out.println("Termin� la randomisation d'un Espace !");
    }
    
    public Proprietaire attribuePlanetesLibres() {
        Proprietaire lProprietaire = new Proprietaire();
        lProprietaire.asgnNom("certains pirates inconnus..");
        lProprietaire.asgnRace(new Race("Pirates", 1.0, 0.8, 0.5, 1.0)); // Produisent moins d'unit�s et se d�fendent moins bien
        lProprietaire.asgnEstJoueur(false);

        Planete lPlanete;
        for (int i = 0; i<aListePlanete.size(); ++i) {
            lPlanete = (Planete)aListePlanete.get(i);
            if (lPlanete.reqProprietaire() == null) {
                lPlanete.asgnProprietaire(lProprietaire);
            }
        }
        
        return lProprietaire;
    }
    
    public void libereRessourcesMinimales() {
        aListePlanete = null;
        aListeFlotte = null;
        aListeProprietaire = null;
        aListeNomPlanete = null;
        aListeEtoiles = null;
        
        if (aGestionnaireCommande != null) {
            aGestionnaireCommande.libereRessources();
            aGestionnaireCommande = null;
        }
        
        if (aGestionnaireProprietaire != null) {
            aGestionnaireProprietaire.libereRessources();
            aGestionnaireProprietaire = null;
        }
        
        for (int i = 0; i<aEspace.length; ++i) {
            for (int j = 0; j<aEspace[i].length; ++j) {
                aEspace[i][j] = null;
            }
        }
        
    }
    
    public void libereRessources() {
        libereRessourcesMinimales();
        
        if (aTimer != null) {
            aTimer.stop();
            aTimer.removeActionListener(this);
            aTimer = null;
        }
        
        if (aDonnees != null) {
            aDonnees.libereRessources();
            aDonnees = null;
        }
        
        aStats = null;
        
        aPlaneteSource = null;
        aPlaneteDestination = null;
        
        removeMouseListener(this);
        removeMouseMotionListener(this);
    }
    
    protected void finalize() throws Throwable {
        super.finalize();
        System.out.println("Mort de l'Espace !");
    }
    
    private void additionneEcouteurs() {
        addMouseListener(this);
        addMouseMotionListener(this);
    }
    
    public void mousePressed(MouseEvent pEvenement) {
        // Asgn la source ..
        int lPosX = (int)(pEvenement.getX()/10);
        int lPosY = (int)(pEvenement.getY()/10);
        
        if ((lPosX < 64) && (lPosY < 40)) {
            Planete lPlanete = aEspace[lPosX][lPosY];
            if (lPlanete != null) {
                if (lPlanete.reqProprietaire() == aGestionnaireProprietaire.reqProprietaireCourant()) {
                    // On a le droit de la prendre comme source.
                    aPlaneteSource = lPlanete;
                    aDonnees.afficheSource(lPlanete);
                    
                    if (aPlaneteSource == aPlaneteDestination) {
                        aPlaneteDestination = null;
                        aDonnees.afficheDestination("");
                    }
                    
                    aEnregistreCommande = false;
                    if (pEvenement.getModifiers() == 4) {
                        // On dis d'enregistrer cette commande
                        aEnregistreCommande = true;
                    } else if (pEvenement.getModifiers() == 10) {
                        // On enleve la commande sur cette planete
                        if (lPlanete.reqEstCommandee()){
                            aGestionnaireCommande.enlevePlanete(lPlanete);
                            aDonnees.affiche();
                        }
                    }
                }
            }
        }
    }
    
    public void mouseReleased(MouseEvent pEvenement) {
        // Asgn la destination ..
        int lPosX = (int)(pEvenement.getX()/10);
        int lPosY = (int)(pEvenement.getY()/10);
        
        if ((lPosX < 64) && (lPosY < 40)) {
            Planete lPlanete = aEspace[lPosX][lPosY];
            if ((lPlanete != null) && (lPlanete != aPlaneteSource)) {
                // On a le droit de la prendre comme destination
                aPlaneteDestination = lPlanete;
                aDonnees.afficheDestination(lPlanete);
            }
        }
    }
    
    public void mouseClicked(MouseEvent pEvenement) {
        // Le click n'as aucune importance !
                /*
                int lPosX = (int)(pEvenement.getX()/10);
                int lPosY = (int)(pEvenement.getY()/10);
                 
                if ((lPosX < 64) && (lPosY < 40)) {
                    if (aEspace[lPosX][lPosY] != null) {
                        // On a click� � un endroit �tant une plan�te !
                        System.out.println(aEspace[lPosX][lPosY]);
                    }
                }
                 
                System.out.println("V : " + pEvenement.getModifiers());
                 */
    }
    
    public void mouseMoved(MouseEvent pEvenement) {
        int lPosX = (int)(pEvenement.getX()/10);
        int lPosY = (int)(pEvenement.getY()/10);
        
        if ((lPosX < 64) && (lPosY < 40)) {
            if (aEspace[lPosX][lPosY] != null) {
                // On est vis-a-vis une planete
                aDonnees.affichePlanete(aEspace[lPosX][lPosY]);
            }
        }
        
    }
    
    public void mouseDragged(MouseEvent pEvenement) {
        int lPosX = (int)(pEvenement.getX()/10);
        int lPosY = (int)(pEvenement.getY()/10);
        
        if ((lPosX < 64) && (lPosY < 40)) {
            if (aEspace[lPosX][lPosY] != null) {
                // On est vis-a-vis une planete
                aDonnees.affichePlanete(aEspace[lPosX][lPosY]);
            }
        }
        
    }
    
    public void mouseExited(MouseEvent pEvenement) {
        
    }
    
    public void mouseEntered(MouseEvent pEvenement) {
        
    }
    
    public void asgnUtilitaires(Donnees pDonnees, Statistiques pStatistiques) {
        aDonnees = pDonnees;
        aStats = pStatistiques;
        
        aGestionnaireCommande.asgnEspace(this);
    }
    
    public boolean lisNomPlanetes() {
        aListeNomPlanete = new Vector();
        try {
            RandomAccessFile lFichier = new RandomAccessFile("c:\\starname.txt", "r");
            
            int lLongueur = (int)lFichier.length();
            byte lBytes[] = new byte[lLongueur];
            
            lFichier.readFully(lBytes);
            int lDebut = 0;
            for (int i = 0; i<lBytes.length; ++i) {
                // System.out.println("C : '" + (int)lBytes[i] + "'");
                if (lBytes[i] == 10) {
                    aListeNomPlanete.add(new String(lBytes, lDebut, i-lDebut-1, "US-ASCII"));
                    lDebut = i+1;
                }
            }
        } catch (Exception pException) {
            System.out.println("Exception avec le fichier de nom d'�toiles.");
            return false;
        }
        
        return true;
    }
    
    public boolean creePlanetes(int pNbPlanetes, int pLargeur, int pHauteur) {
        if (aListePlanete == null) {
            aListePlanete = new Vector();
        }
        
        if (aEspace == null) {
            aEspace = new Planete[pLargeur][pHauteur];
        } else {
            if ((aEspace.length != pLargeur) || (aEspace[0].length != pHauteur)) return false;
            if (((pLargeur * pHauteur) - aListePlanete.size()) < pNbPlanetes) return false;
        }
        
        for (int i = 0; i<pNbPlanetes; ++i) {
            int lX, lY, lN;
            do {
                lX = (int)(Math.random() * pLargeur);
                lY = (int)(Math.random() * pHauteur);
            } while (aEspace[lX][lY] != null);
            
            lN = (int)(Math.random() * aListeNomPlanete.size());
            aEspace[lX][lY] = new Planete(lX, lY, (String)aListeNomPlanete.get(lN));
            aListePlanete.add(aEspace[lX][lY]);
            aListeNomPlanete.remove(lN);
        }
        
        return true;
    }
    
    public void creeEtoiles(int pNbEtoiles) {
        if (aListeEtoiles == null) {
            aListeEtoiles = new Vector();
        } else {
            aListeEtoiles.clear();
        }
        
        additionneEtoiles(pNbEtoiles);
    }
    
    public void additionneEtoiles(int pNbEtoiles) {
        double lPosX, lPosY, lVitesse, lAngle;
        for (int i = 0; i<pNbEtoiles; ++i) {
            lPosX = 640 * Math.random();
            lPosY = 400 * Math.random();
            lVitesse = 0.75 + 5 * Math.random();
            lAngle = 2 * Math.PI * Math.random();
            
            aListeEtoiles.add(new Stars(lPosX, lPosY, lVitesse * Math.cos(lAngle), lVitesse * Math.sin(lAngle)));
        }
    }
    
    public void asgnNbEtoiles(int pNbEtoiles) {
        if (aListeEtoiles.size() <= pNbEtoiles) {
            additionneEtoiles(pNbEtoiles - aListeEtoiles.size());
        } else {
            aListeEtoiles.setSize(pNbEtoiles);
        }
        
        if (pNbEtoiles == 0) {
            asgnRafraichissementEtoiles(0);
        }
    }
    
    public void asgnRafraichissementEtoiles(int pTemps) {
        if (pTemps == 0) {
            if (aTimer != null) {
                aTimer.stop();
                aTimer = null;
            }
        } else {
            // System.out.println("Timer : " + pTemps);
            if (aTimer == null) {
                aTimer = new Timer(pTemps, this);
            } else {
                aTimer.setDelay(pTemps);
            }
            aTimer.start();
        }
    }
    
    public void reassigneCouleurs() {
        Iterator lIterateur = aListePlanete.listIterator();
        
        while (lIterateur.hasNext()) {
            ((Planete)lIterateur.next()).asgnCouleur();
        }
    }
    
    public void actionPerformed(ActionEvent pEvenement) {
        repaint();
    }
    
    public void avanceJoueur() {
        // On avance au prochain joueur ..
        aEnregistreCommande = false;
        aDonnees.reinitialise();
        
        aPlaneteSource = null;
        aPlaneteDestination = null;
        
        Proprietaire lProprietaire;
        boolean lAvanceTour = false;
        do {
            if (aGestionnaireProprietaire.avanceProprietaire()) {
                lProprietaire = aGestionnaireProprietaire.reqProprietaireCourant();
            } else {
                // On a termin� le tour ..
                lAvanceTour = true;
                lProprietaire = new Proprietaire();
            }
        } while ((!lProprietaire.reqEstJoueur()) || ((!lAvanceTour) && (lProprietaire.reqNbPlanete() == 0)));
        
        if (lAvanceTour) {
            avanceTour();
        } else {
            aStats.affiche(lProprietaire);
            aDonnees.affiche();
        }
    }
    
    public void avanceTour() {
        // Toutes les planetes produisent leur arm�e
        for (int i = 0; i<aListePlanete.size(); ++i) {
            ((Planete)aListePlanete.get(i)).avanceTour();
        }
        
        // Toutes les flottes avances et se battent
        for (int i = 0; i<aListeFlotte.size(); ++i) {
            Flotte lFlotte = ((Flotte)aListeFlotte.get(i));
            if (lFlotte.avanceTour()) {
                // On est arriv� a destination !
                lFlotte.reqDestination().recoitFlotte(lFlotte);
                aListeFlotte.remove(i);
            }
        }
        
        // On r�affiche les planetes afin de s'assurer qu'elles sont de la bonne couleur !
        repaint();
        
        // On remet les propri�t�s des proprios � 0..
        Iterator lIterateurProprietaire = aListeProprietaire.listIterator(0);
        while (lIterateurProprietaire.hasNext()) {
            Proprietaire lProprietaire = (Proprietaire)lIterateurProprietaire.next();
            
            lProprietaire.asgnNbPlanete(0);
            lProprietaire.asgnNbFlotte(0);
            lProprietaire.asgnNbVaisseau(0);
            lProprietaire.asgnNbProduction(0);
        }
        
        // On compte le Nb de Vaisseaux & de Plan�tes  ..
        for (int i = 0; i<aListePlanete.size(); ++i) {
            Planete lPlanete = (Planete)aListePlanete.get(i);
            Proprietaire lProprietaire = lPlanete.reqProprietaire();
            if (lProprietaire != null) {
                lProprietaire.addNbVaisseau(lPlanete.reqNbVaisseau());
                lProprietaire.addNbPlanete(1);
                lProprietaire.addNbProduction(lPlanete.reqProduction());
            }
        }
        
        // On compte le Nb de Flottes ..
        for (int i = 0; i<aListeFlotte.size(); ++i) {
            ((Flotte)aListeFlotte.get(i)).reqProprietaire().addNbFlotte(1);
        }
        
        // On �limine les corps morts ..
        lIterateurProprietaire = aListeProprietaire.listIterator(0);
        while (lIterateurProprietaire.hasNext()) {
            Proprietaire lProprietaire = (Proprietaire)lIterateurProprietaire.next();
            if ((lProprietaire.reqNbPlanete() == 0) && (lProprietaire.reqNbFlotte() == 0)) {
                JOptionPane.showMessageDialog(null, lProprietaire.reqNom() + " n'as plus de plan�te ni de flotte. Il a donc perdu.", "Looser !", JOptionPane.PLAIN_MESSAGE);
                lIterateurProprietaire.remove();
            }
        }
        
        // S'il ne reste qu'un propri�taire il a gagn� ..
        if (aListeProprietaire.size() == 1) {
            JOptionPane.showMessageDialog(null, ((Proprietaire)aListeProprietaire.get(0)).reqNom() + " a gagn� !", "Winner !", JOptionPane.PLAIN_MESSAGE);
            aDonnees.arreteBoutonTermine();
        } else {
            // Sinon il faut avancer au prochain propri�taire ..
            aEnregistreCommande = false;
            aGestionnaireProprietaire.initialise();
            aGestionnaireCommande.envoieFlottes();
            avanceJoueur();
        }
    }
    
    public void envoieFlotte(Planete pPlaneteSource, Planete pPlaneteDestination, int pNbVaisseau) {
        if ((pPlaneteSource != null) && (pPlaneteDestination != null) && (pNbVaisseau > 0)) {
            if (pPlaneteSource.reqNbVaisseau() >= pNbVaisseau) {
                Proprietaire lProprietaire = pPlaneteSource.reqProprietaire();
                aListeFlotte.add(new Flotte(lProprietaire,
                pNbVaisseau,
                (int)(pPlaneteSource.reqTemps(pPlaneteDestination)),
                pPlaneteDestination));
                
                if (aEnregistreCommande) {
                    aGestionnaireCommande.additionneCommande(pPlaneteSource, pPlaneteDestination, pNbVaisseau);
                }
                
                pPlaneteSource.soustraitNbVaisseau(pNbVaisseau);
                aDonnees.affiche();
                
                lProprietaire.addNbVaisseau(-pNbVaisseau);
                lProprietaire.addNbFlotte(1);
                
                aStats.affiche(lProprietaire);
            }
        }
    }
    
    public void envoieFlotte(int pNbVaisseau) {
        envoieFlotte(aPlaneteSource, aPlaneteDestination, pNbVaisseau);
    }
    
    public void enregistre(String pNomFichier) {
        // Enregistre le fichier contenant toutes les informations
        if ((aListeEtoiles != null) && (aListeProprietaire != null) && (aListePlanete != null) && (aListeFlotte != null) && (aGestionnaireProprietaire != null) && (aGestionnaireCommande != null) && (aEspace != null)) {
            try {
                DataOutputStream lFichier = new DataOutputStream(new GZIPOutputStream(new FileOutputStream(pNomFichier)));
                
                try {
                    lFichier.writeUTF("SAUVEGARDE DEBUT");
                    
                    // Etoiles
                    lFichier.writeInt(aListeEtoiles.size());
                    if (aListeEtoiles.size() != 0) {
                        Iterator lIterateur = aListeEtoiles.listIterator();
                        while (lIterateur.hasNext()) {
                            ((Stars)lIterateur.next()).enregistre(lFichier);
                        }
                        lFichier.writeInt(aTimer.getDelay());
                    }
                    
                    // Proprietaires
                    lFichier.writeInt(aListeProprietaire.size());
                    for (int i = 0; i <aListeProprietaire.size(); ++i) {
                        Proprietaire lProprietaire = (Proprietaire)aListeProprietaire.get(i);
                        lProprietaire.asgnID(i);
                        lProprietaire.enregistre(lFichier);
                    }
                    
                    // Planetes
                    lFichier.writeInt(aListePlanete.size());
                    for (int i = 0; i < aListePlanete.size(); ++i) {
                        Planete lPlanete = (Planete)aListePlanete.get(i);
                        lPlanete.asgnID(i);
                        lPlanete.enregistre(lFichier);
                    }
                    
                    // Flottes
                    lFichier.writeInt(aListeFlotte.size());
                    if (aListeFlotte.size() != 0) {
                        Iterator lIterateur = aListeFlotte.listIterator();
                        while (lIterateur.hasNext()) {
                            ((Flotte)lIterateur.next()).enregistre(lFichier);
                        }
                    }
                    
                    // Gestion Commandes
                    aGestionnaireCommande.enregistre(lFichier);
                    
                    // Gestion Proprietaire
                    aGestionnaireProprietaire.enregistre(lFichier);
                    
                    lFichier.writeUTF("SAUVEGARDE FIN");
                } catch (IOException pEvenement) {
                    System.out.println("Erreur lors de l'�criture : " + pEvenement.toString());
                } finally {
                    lFichier.close();
                }
            } catch (FileNotFoundException pEvenement) {
                System.out.println("Impossible d'�crire le fichier : " + pEvenement.toString());
            } catch (IOException pEvenement) {
                System.out.println("Probl�me avec GZIP : " + pEvenement.toString());
            }
        }
    }
    
    public void paint(Graphics pGraphics) {
        pGraphics.setColor(Color.black);
        pGraphics.fillRect(0, 0, 640, 400);
        
        if (aListeEtoiles != null) {
            for (int i = 0; i<aListeEtoiles.size(); ++i) {
                if (!((Stars)aListeEtoiles.get(i)).paint(pGraphics)) {
                    double lVitesse = 0.75 + 5 * Math.random();
                    double lAngle = Math.PI * Math.random();
                    
                    aListeEtoiles.set(i, new Stars(lVitesse, lAngle));
                }
            }
        }
        
        for (int i = 0; i<aListePlanete.size(); ++i) {
            ((Planete)(aListePlanete.get(i))).paint(pGraphics);
        }
    }
    
    /**
     * Proc�dure Test cr�ant un objet d'affichage et le pla�ant sur un JFrame
     *
     * @param args Arguments de la ligne de commande, non utilis�
     */
    public static void main(String args[]) {
        JFrame lApplication = new JFrame("Espace MiniGame");
        
        Donnees lDonnees = new Donnees();
        Statistiques lStats = new Statistiques();
        Espace lEspace = new Espace();
        
        lDonnees.asgnEspace(lEspace);
        lEspace.asgnUtilitaires(lDonnees, lStats);
        lEspace.avanceTour();
        
        lApplication.getContentPane().add(lEspace, BorderLayout.CENTER);
        lApplication.getContentPane().add(lDonnees, BorderLayout.SOUTH);
        lApplication.getContentPane().add(lStats, BorderLayout.NORTH);
        lApplication.addWindowListener
        (
        new WindowAdapter() {
            public void windowClosing(WindowEvent pEvenement) {
                System.exit(0);
            }
        }
        );
        
        lApplication.setSize(648, 488);
        lApplication.show();
    }
}

