import java.awt.Color;

public class Proprietaire extends Object {
    private Color mCouleur;
    private String mNom;
    private Race mRace;
    private boolean mEstJoueur;
    
    private int mNbVaisseau, mNbPlanete, mNbFlotte, mNbProduction;

    Proprietaire(String pNom, Color pCouleur) {
        mNom = pNom;
        mCouleur = pCouleur;
        
        initialiseVariables();
    }
        
    Proprietaire() {
        initialiseVariables();
    }
    
    private void initialiseVariables() {
        mNbVaisseau = 0;
        mNbPlanete = 0;
        mNbFlotte = 0;
        mNbProduction = 0;

        mRace = null;
        mEstJoueur = true;
    }

    public void asgnEstJoueur(boolean pValeur) {
        mEstJoueur = pValeur;
    }
    
    public boolean reqEstJoueur() {
        return mEstJoueur;
    }
    
    public void asgnRace(Race pRace) {
        mRace = pRace;
    }

    public String reqNom() {
        return mNom;
    }
    
    public void asgnNom(String pNom) {
        mNom = pNom;
    }
    
    public Color reqCouleur() {
        return mCouleur;
    }
    
    public void asgnCouleur(Color pCouleur) {
        mCouleur = pCouleur;
    }

    public void asgnNbVaisseau(int pNbVaisseau) {
        mNbVaisseau = pNbVaisseau;
    }
    
    public void asgnNbPlanete(int pNbPlanete) {
        mNbPlanete = pNbPlanete;
    }
    
    public void asgnNbFlotte(int pNbFlotte) {
        mNbFlotte = pNbFlotte;
    }
    
    public void asgnNbProduction(int pNbProduction) {
        mNbProduction = pNbProduction;
    }

    public void addNbVaisseau(int pNbVaisseau) {
        mNbVaisseau += pNbVaisseau;
    }
    
    public void addNbPlanete(int pNbPlanete) {
        mNbPlanete += pNbPlanete;
    }
    
    public void addNbFlotte(int pNbFlotte) {
        mNbFlotte += pNbFlotte;
    }

    public void addNbProduction(int pNbProduction) {
        mNbProduction += pNbProduction;
    }

    public int reqNbVaisseau() {
        return mNbVaisseau;
    }
    
    public int reqNbPlanete() {
        return mNbPlanete;
    }
    
    public int reqNbFlotte() {
        return mNbFlotte;
    }
    
    public int reqNbProduction() {
        return mNbProduction;
    }
    
    public double reqBonusAttaque() {
        if (mRace != null) {
            return mRace.reqAttaque();
        } else {
            return 1.0;
        }
    }
    
    public double reqBonusDefense() {
        if (mRace != null) {        
            return mRace.reqDefense();
        } else {
            return 1.0;
        }
    }
    
    public double reqBonusProduction() {
        if (mRace != null) {        
            return mRace.reqProduction();
        } else {
            return 1.0;
        }
    }
    
    public double reqBonusDeplacement() {
        if (mRace != null) {        
            return mRace.reqDeplacement();
        } else {
            return 1.0;
        }
    }
}
