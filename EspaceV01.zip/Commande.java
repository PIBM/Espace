
public class Commande extends Object {
    private Planete aPlaneteSource, aPlaneteDestination;
    private int aNbVaisseau;
    
    Commande(Planete pSource, Planete pDestination, int pNbVaisseau) {
        aPlaneteSource = pSource;
        aPlaneteDestination = pDestination;
        aNbVaisseau = pNbVaisseau;
    }
    
    public Planete reqPlaneteSource() {
        return aPlaneteSource;
    }
    
    public Planete reqPlaneteDestination() {
        return aPlaneteDestination;
    }
    
    public int reqNbVaisseau() {
        return aNbVaisseau;
    }
}