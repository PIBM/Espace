public class Race extends Object {
    
    private String mNom;
    private double mPoints, mAttaque, mDefense, mProduction, mDeplacement;
    private boolean mModifiable;
    
    Race(String pNom, double pPoints) {
        mNom = pNom;
        mAttaque = pPoints / 4;
        mDefense = mAttaque;
        mProduction = mAttaque;
        mDeplacement = mAttaque;
        
        mModifiable = true;
    }
    
    Race(String pNom, double pAttaque, double pDefense, double pProduction, double pDeplacement) {
        mNom = pNom;
        
        mAttaque = pAttaque;
        mDefense = pDefense;
        mProduction = pProduction;
        mDeplacement = pDeplacement;
        
        mModifiable = false;
    }
    
    public String toString() {
        return mNom;
    }
    
    public boolean reqModifiable() {
        return mModifiable;
    }
    
    public double reqNorme() {
        return (mAttaque + mDefense + mProduction + mDeplacement);
    }
    
    public double reqMax() {
        return Math.max(Math.max(mAttaque, mDefense), Math.max(mProduction, mDeplacement));
    }
    
    public double reqAttaque() {
        return mAttaque;
    }
    
    public double reqDefense() {
        return mDefense;
    }
    
    public double reqProduction() {
        return mProduction;
    }
    
    public double reqDeplacement() {
        return mDeplacement;
    }
    
    public double diminue(int pNum, double pDemande) {
        double lValeur = 0;
        
        if ((pNum & 1) != 0) {
            if (mAttaque - 0.25 > pDemande) {
                lValeur += pDemande;
                mAttaque -= pDemande;
            } else if (mAttaque > 0.25) {
                lValeur += mAttaque - 0.25;
                mAttaque = 0.25;
            }
        }
        
        if ((pNum & 2) != 0) {
            if (mDefense - 0.25 > pDemande) {
                lValeur += pDemande;
                mDefense -= pDemande;
            } else if (mDefense > 0.25) {
                lValeur += mDefense - 0.25;
                mDefense = 0.25;
            }
        }

        if ((pNum & 4) != 0) {
            if (mProduction - 0.25 > pDemande) {
                lValeur += pDemande;
                mProduction -= pDemande;
            } else if (mProduction > 0.25) {
                lValeur += mProduction - 0.25;
                mProduction = 0.25;
            }
        }

        if ((pNum & 8) != 0) {
            if (mDeplacement - 0.25 > pDemande) {
                lValeur += pDemande;
                mDeplacement -= pDemande;
            } else if (mDeplacement > 0.25) {
                lValeur += mDeplacement - 0.25;
                mDeplacement = 0.25;
            }
        }
        
        return lValeur;
    }
    
    public void additionne(int pNum, double pValeur) {
        if ((pNum & 1) != 0) {
            mAttaque += pValeur;
        }
        
        if ((pNum & 2) != 0) {
            mDefense += pValeur;
        }

        if ((pNum & 4) != 0) {
            mProduction += pValeur;
        }

        if ((pNum & 8) != 0) {
            mDeplacement += pValeur;
        }
    }
    
    public void incAttaque() {
        mAttaque += diminue(14, 0.04);
    }
    
    public void decAttaque() {
        double lValeur = 0;
        if ((mAttaque - 0.12) > 0.25) {
            lValeur = 0.04;
        } else if (mAttaque > 0.25) {
            lValeur = (mAttaque - 0.25)/3;
        }
        additionne(14, lValeur);
        mAttaque -= lValeur;
    }
    
    public void incDefense() {
        mDefense += diminue(13, 0.04);
    }

    public void decDefense() {
        double lValeur = 0;
        if ((mDefense - 0.12) > 0.25) {
            lValeur = 0.04;
        } else if (mDefense > 0.25) {
            lValeur = (mDefense - 0.25)/3;
        }
        additionne(13, lValeur);
        mDefense -= lValeur;
    }
    
    public void incProduction() {
        mProduction += diminue(11, 0.04);
    }

    public void decProduction() {
        double lValeur = 0;
        if ((mProduction - 0.12) > 0.25) {
            lValeur = 0.04;
        } else if (mProduction > 0.25) {
            lValeur = (mProduction - 0.25)/3;
        }
        additionne(11, lValeur);
        mProduction -= lValeur;
    }

    public void incDeplacement() {
        mDeplacement += diminue(7, 0.04);
    }
    
    public void decDeplacement() {
        double lValeur = 0;
        if ((mDeplacement - 0.12) > 0.25) {
            lValeur = 0.04;
        } else if (mDeplacement > 0.25) {
            lValeur = (mDeplacement - 0.25)/3;
        }
        additionne(7, lValeur);
        mDeplacement -= lValeur;
    }
}
