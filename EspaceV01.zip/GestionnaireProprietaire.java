import java.util.AbstractList;
import java.util.ListIterator;

public class GestionnaireProprietaire extends Object {
    AbstractList mListeProprietaire;
    ListIterator mIterateurProprietaire;
    Proprietaire mProprietaireCourant;
    
    GestionnaireProprietaire(AbstractList pListeProprietaire) {
        mListeProprietaire = pListeProprietaire;        
        mProprietaireCourant = new Proprietaire();
    }
    
    public void initialise() {
        mIterateurProprietaire = mListeProprietaire.listIterator(0);
    }
    
    public boolean avanceProprietaire() {
        
        if (mIterateurProprietaire.hasNext()) {
            mProprietaireCourant = (Proprietaire)mIterateurProprietaire.next();
            return true;
        }
        
        return false;
    }
    
    public Proprietaire reqProprietaireCourant() {
        return mProprietaireCourant;
    }
    
    public void libereRessources() {
        mListeProprietaire = null;
        mIterateurProprietaire = null;
        mProprietaireCourant = null;
    }
}
