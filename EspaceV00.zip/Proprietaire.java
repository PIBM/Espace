import java.awt.Color;

public class Proprietaire extends Object {
    private Color mCouleur;
    private String mNom;
    
    private int mNbVaisseau, mNbPlanete, mNbFlotte, mNbProduction;

    Proprietaire(String pNom, Color pCouleur) {
        mNom = pNom;
        mCouleur = pCouleur;
        mNbVaisseau = 0;
        mNbPlanete = 0;
        mNbFlotte = 0;
        mNbProduction = 0;
    }
        
    public String reqNom() {
        return mNom;
    }
    
    public Color reqCouleur() {
        return mCouleur;
    }
    
    public void asgnNbVaisseau(int pNbVaisseau) {
        mNbVaisseau = pNbVaisseau;
    }
    
    public void asgnNbPlanete(int pNbPlanete) {
        mNbPlanete = pNbPlanete;
    }
    
    public void asgnNbFlotte(int pNbFlotte) {
        mNbFlotte = pNbFlotte;
    }
    
    public void asgnNbProduction(int pNbProduction) {
        mNbProduction = pNbProduction;
    }

    public void addNbVaisseau(int pNbVaisseau) {
        mNbVaisseau += pNbVaisseau;
    }
    
    public void addNbPlanete(int pNbPlanete) {
        mNbPlanete += pNbPlanete;
    }
    
    public void addNbFlotte(int pNbFlotte) {
        mNbFlotte += pNbFlotte;
    }

    public void addNbProduction(int pNbProduction) {
        mNbProduction += pNbProduction;
    }

    public int reqNbVaisseau() {
        return mNbVaisseau;
    }
    
    public int reqNbPlanete() {
        return mNbPlanete;
    }
    
    public int reqNbFlotte() {
        return mNbFlotte;
    }
    
    public int reqNbProduction() {
        return mNbProduction;
    }
}
