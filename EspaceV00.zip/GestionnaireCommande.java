import java.util.AbstractList;
import java.util.LinkedList;
import java.util.ListIterator;

public class GestionnaireCommande extends Object {
    private AbstractList aListeCommande;
    private Espace aEspace;
    
    GestionnaireCommande() {
        aListeCommande = new LinkedList();
    }
    
    public void additionneCommande(Planete pPlaneteSource, Planete pPlaneteDestination, int pNbVaisseau) {
        enlevePlanete(pPlaneteSource);
        
        aListeCommande.add(new Commande(pPlaneteSource, pPlaneteDestination, pNbVaisseau));
        pPlaneteSource.asgnEstCommandee(true);
    }
    
    public void enlevePlanete(Planete pPlanete) {
        ListIterator lIterateur = aListeCommande.listIterator();
        
        while(lIterateur.hasNext()) {
            Commande lCommande = (Commande)lIterateur.next();
            
            if (lCommande.reqPlaneteSource() == pPlanete) {
                lIterateur.remove();
                break;
            }
        }
        
        pPlanete.asgnEstCommandee(false);
    }
    
    public void envoieFlottes() {
        ListIterator lIterateur = aListeCommande.listIterator();
        
        while(lIterateur.hasNext()) {
            Commande lCommande = (Commande)lIterateur.next();
            if (lCommande.reqPlaneteSource().reqEstCommandee()) {
                aEspace.envoieFlotte(lCommande.reqPlaneteSource(), lCommande.reqPlaneteDestination(), lCommande.reqNbVaisseau());
            } else {
                lIterateur.remove();
            }
        }
    }
    
    public void asgnEspace(Espace pEspace) {
        aEspace = pEspace;
    }
}