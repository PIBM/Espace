import javax.swing.JOptionPane;
import java.awt.Graphics;
import java.awt.Color;

public class Planete extends Object {
    private int mPositionX, mPositionY;
    private int mProduction, mNbVaisseau;
    private double mForce;
    private boolean mEstCommandee;
    private Color mCouleur;
    private String mNom;
    private Proprietaire mProprietaire;
    
    Planete(int pPositionX, int pPositionY, String pNom) {
        mPositionX = pPositionX;
        mPositionY = pPositionY;
        
        // mCouleur = new Color(150+(int)(Math.random() * 100), 150+(int)(Math.random() * 100), 150+(int)(Math.random() * 100));
        mCouleur = new Color(100+(int)(Math.random() * 100), 100+(int)(Math.random() * 100), 100+(int)(Math.random() * 100));
        mNbVaisseau = 0;
        mForce = 0.75 + (Math.random() * 0.5);
        mProduction = 6 + (int)Math.pow(Math.random() * 4, 2);
        mNom = pNom;
        
        mEstCommandee = false;
    }

    public void paint(Graphics pGraphics) {
        pGraphics.setColor(mCouleur);
        pGraphics.fillOval(10 * mPositionX, 10*mPositionY, 10, 10);
    }
    
    public void asgnProprietaire(Proprietaire pProprietaire) {
        mProprietaire = pProprietaire;
        mCouleur = mProprietaire.reqCouleur();
    }
    
    public Proprietaire reqProprietaire() {
        return mProprietaire;
    }

    public void asgnProduction(int pProduction) {
        mProduction = pProduction;
    }
    
    public int reqProduction() {
        return mProduction;
    }
    
    public int reqNbVaisseau() {
        return mNbVaisseau;
    }
    
    public void soustraitNbVaisseau(int pNbVaisseau) {
        mNbVaisseau -= pNbVaisseau;
    }
    
    public String reqNom() {
        return mNom;
    }
    
    public void asgnEstCommandee(boolean pValeur) {
        mEstCommandee = pValeur;
    }
    
    public boolean reqEstCommandee() {
        return mEstCommandee;
    }
    
    public int reqDistance(Planete pDestination) {
        System.out.println ("Temps " + mNom + " -> " + pDestination.reqNom() + " : " + (int)Math.sqrt((pDestination.mPositionX - mPositionX)*(pDestination.mPositionX - mPositionX)+(pDestination.mPositionY - mPositionY)*(pDestination.mPositionY - mPositionY)) + ".");
        
        return (int)Math.sqrt((pDestination.mPositionX - mPositionX)*(pDestination.mPositionX - mPositionX)+
                              (pDestination.mPositionY - mPositionY)*(pDestination.mPositionY - mPositionY));
    }
    
    public String toString() {
        String lString = "Plan�te '" + mNom + "', ";
        
        if (mProprietaire == null) 
            lString += "libre.";
        else
            lString += "appartenant � " + mProprietaire.reqNom() + " et produisant " + mProduction + " unit�s par tour.";
        
        return lString;
    }
        
    public void avanceTour() {
        mNbVaisseau += mProduction;
    }
    
    public void recoitFlotte(Flotte pFlotte) {
        if (mProprietaire == pFlotte.reqProprietaire()) {
            mNbVaisseau += pFlotte.reqNbVaisseau();
            JOptionPane.showMessageDialog(null, "Renfort arriv�s � la planete " + mNom + ", propri�t� de " + mProprietaire.reqNom() + " !");
        } else {
            double lAttaque = pFlotte.reqNbVaisseau();
            double lDefense = mNbVaisseau * mForce;
            
            String lNom;
            if (mProprietaire == null) {
                lDefense *= 0.33;
                lNom = "certains pirates inconnus..";
            } else {
                lNom = mProprietaire.reqNom();
            }
            
            if (lAttaque > lDefense) {
                JOptionPane.showMessageDialog(null, pFlotte.reqProprietaire().reqNom() + " a pris la plan�te " + mNom + ", ancienne propri�t� de " + lNom + " !");
                mProprietaire = pFlotte.reqProprietaire();
                mCouleur = mProprietaire.reqCouleur();
                mNbVaisseau = (int)(lAttaque - lDefense*0.66);
                
                mEstCommandee = false;
            } else {
                mNbVaisseau = (int)((lDefense - (0.66 * lAttaque))/mForce);
                JOptionPane.showMessageDialog(null, pFlotte.reqProprietaire().reqNom() + " a attaqu� la plan�te " + mNom + ", propri�t� de " + lNom + " !");
            }
        }
    }
    
}