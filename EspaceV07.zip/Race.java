import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;

public class Race extends Object {
    
    private String mNom;
    private double mPoints, mAttaque, mDefense, mProduction, mDeplacement;
    private boolean mModifiable;
    
    Race(String pNom, double pPoints) {
        mNom = pNom;
        mAttaque = pPoints / 4;
        mDefense = mAttaque;
        mProduction = mAttaque;
        mDeplacement = mAttaque;
        
        mModifiable = true;
    }
    
    Race(String pNom, double pAttaque, double pDefense, double pProduction, double pDeplacement) {
        mNom = pNom;
        
        mAttaque = pAttaque;
        mDefense = pDefense;
        mProduction = pProduction;
        mDeplacement = pDeplacement;
        
        mModifiable = false;
    }
    
    Race(DataInputStream pFichier) throws IOException {
        if (pFichier.readUTF().compareTo("RACE") != 0) throw new IOException("On essai de lire une Race alors que �a n'en est pas une !");
        mNom = pFichier.readUTF();
        mPoints = pFichier.readDouble();
        mAttaque = pFichier.readDouble();
        mDefense = pFichier.readDouble();
        mProduction = pFichier.readDouble();
        mDeplacement = pFichier.readDouble();
        mModifiable = pFichier.readBoolean();
    }
    
    public void enregistre(DataOutputStream pFichier) throws IOException {
        pFichier.writeUTF("RACE");
        pFichier.writeUTF(mNom);
        pFichier.writeDouble(mPoints);
        pFichier.writeDouble(mAttaque);
        pFichier.writeDouble(mDefense);
        pFichier.writeDouble(mProduction);
        pFichier.writeDouble(mDeplacement);
        pFichier.writeBoolean(mModifiable);
    }
    
    public String toString() {
        return mNom;
    }
    
    public boolean reqModifiable() {
        return mModifiable;
    }
    
    public double reqNorme() {
        return (mAttaque + mDefense + mProduction + mDeplacement);
    }
    
    public double reqMax() {
        return Math.max(Math.max(mAttaque, mDefense), Math.max(mProduction, mDeplacement));
    }
    
    public double reqAttaque() {
        return mAttaque;
    }
    
    public double reqDefense() {
        return mDefense;
    }
    
    public double reqProduction() {
        return mProduction;
    }
    
    public double reqDeplacement() {
        return mDeplacement;
    }
    
    private double diminue(int pNum, double pDemande) {
        double lValeur = 0;
        
        if ((pNum & 1) != 0) {
            if (mAttaque - 0.25 > pDemande) {
                lValeur += pDemande;
                mAttaque -= pDemande;
            } else if (mAttaque > 0.25) {
                lValeur += mAttaque - 0.25;
                mAttaque = 0.25;
            }
        }
        
        if ((pNum & 2) != 0) {
            if (mDefense - 0.25 > pDemande) {
                lValeur += pDemande;
                mDefense -= pDemande;
            } else if (mDefense > 0.25) {
                lValeur += mDefense - 0.25;
                mDefense = 0.25;
            }
        }
        
        if ((pNum & 4) != 0) {
            if (mProduction - 0.25 > pDemande) {
                lValeur += pDemande;
                mProduction -= pDemande;
            } else if (mProduction > 0.25) {
                lValeur += mProduction - 0.25;
                mProduction = 0.25;
            }
        }
        
        if ((pNum & 8) != 0) {
            if (mDeplacement - 0.25 > pDemande) {
                lValeur += pDemande;
                mDeplacement -= pDemande;
            } else if (mDeplacement > 0.25) {
                lValeur += mDeplacement - 0.25;
                mDeplacement = 0.25;
            }
        }
        
        return lValeur;
    }
    
    private void additionne(int pNum, double pValeur) {
        if ((pNum & 1) != 0) {
            mAttaque += pValeur;
        }
        
        if ((pNum & 2) != 0) {
            mDefense += pValeur;
        }
        
        if ((pNum & 4) != 0) {
            mProduction += pValeur;
        }
        
        if ((pNum & 8) != 0) {
            mDeplacement += pValeur;
        }
    }
    
    public void incAttaque() {
        if (mModifiable) mAttaque += diminue(14, 0.04);
    }
    
    public void decAttaque() {
        if (mModifiable) {
            double lValeur = 0;
            if ((mAttaque - 0.12) > 0.25) {
                lValeur = 0.12;
            } else if (mAttaque > 0.25) {
                lValeur = (mAttaque - 0.25);
            }
            additionne(14, lValeur/3);
            mAttaque -= lValeur;
        }
    }
    
    public void incDefense() {
        if (mModifiable) mDefense += diminue(13, 0.04);
    }
    
    public void decDefense() {
        if (mModifiable) {
            double lValeur = 0;
            if ((mDefense - 0.12) > 0.25) {
                lValeur = 0.12;
            } else if (mDefense > 0.25) {
                lValeur = (mDefense - 0.25);
            }
            additionne(13, lValeur/3);
            mDefense -= lValeur;
        }
    }
    
    public void incProduction() {
        if (mModifiable) mProduction += diminue(11, 0.04);
    }
    
    public void decProduction() {
        if (mModifiable) {
            double lValeur = 0;
            if ((mProduction - 0.12) > 0.25) {
                lValeur = 0.12;
            } else if (mProduction > 0.25) {
                lValeur = (mProduction - 0.25);
            }
            additionne(11, lValeur/3);
            mProduction -= lValeur;
        }
    }
    
    public void incDeplacement() {
        if (mModifiable) mDeplacement += diminue(7, 0.04);
    }
    
    public void decDeplacement() {
        if (mModifiable) {
            double lValeur = 0;
            if ((mDeplacement - 0.12) > 0.25) {
                lValeur = 0.12;
            } else if (mDeplacement > 0.25) {
                lValeur = (mDeplacement - 0.25);
            }
            additionne(7, lValeur/3);
            mDeplacement -= lValeur;
        }
    }
}
